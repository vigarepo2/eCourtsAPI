plugins {
    id("com.android.application")
}

android {
    namespace = "in.vigarepo.ecourtglass"
    compileSdk = 36

    defaultConfig {
        applicationId = "in.vigarepo.ecourtglass"
        minSdk = 23
        targetSdk = 36
        versionCode = 6
        versionName = "6.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}
