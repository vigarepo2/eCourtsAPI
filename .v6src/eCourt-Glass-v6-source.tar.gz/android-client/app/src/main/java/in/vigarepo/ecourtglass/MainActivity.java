package in.vigarepo.ecourtglass;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    static final int REQ_IMPORT = 4101;
    static final int REQ_EXPORT = 4102;

    private WebView webView;
    private CaseDb db;
    private EcourtsApi api;
    private ExecutorService executor;
    private AppBridge bridge;
    private boolean importAutoSync = false;
    private String importFamily = "DC";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        db = new CaseDb(this);
        db.recoverInterruptedSync();
        api = new EcourtsApi(this);
        executor = Executors.newFixedThreadPool(8);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244,247,251));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setDefaultTextEncodingName("utf-8");
        s.setUserAgentString(s.getUserAgentString() + " eCourtGlass/6.0");
        if (android.os.Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        WebView.setWebContentsDebuggingEnabled(false);
        webView.setWebViewClient(new WebViewClient());

        bridge = new AppBridge(this, webView, db, api, executor);
        webView.addJavascriptInterface(bridge, "Native");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        // Hide first-request session bootstrap behind normal app startup.
        executor.execute(() -> api.warmSession("DC"));
    }

    private void configureWindow() {
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(244,247,251));
        w.setNavigationBarColor(Color.rgb(244,247,251));
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    void chooseJson(boolean autoSync, String family) {
        importAutoSync = autoSync;
        importFamily = "HC".equalsIgnoreCase(family) ? "HC" : "DC";
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain", "application/octet-stream"});
        startActivityForResult(i, REQ_IMPORT);
    }

    void createExportFile() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "ecourt-glass-backup.json");
        startActivityForResult(i, REQ_EXPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && (resultCode != RESULT_OK || data == null || data.getData() == null)) {
            importAutoSync = false;
            importFamily = "DC";
            return;
        }
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_IMPORT) {
            final boolean autoSync = importAutoSync;
            final String family = importFamily;
            importAutoSync = false;
            importFamily = "DC";
            executor.execute(() -> {
                try {
                    String text = readUri(uri);
                    JSONObject result = db.importJson(text, family);
                    js("window.onImportDone && window.onImportDone(" + result.toString() + "," + autoSync + "," + JSONObject.quote(family) + ");");
                } catch (Exception e) {
                    js("window.onImportError && window.onImportError(" + JSONObject.quote(safeMessage(e)) + ");");
                }
            });
        } else if (requestCode == REQ_EXPORT) {
            executor.execute(() -> {
                try {
                    String text = db.exportAll();
                    try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                        if (out == null) throw new IllegalStateException("Cannot open export file");
                        out.write(text.getBytes(StandardCharsets.UTF_8));
                    }
                    js("window.toast && window.toast('Export saved');");
                } catch (Exception e) {
                    js("window.toast && window.toast(" + JSONObject.quote("Export failed: " + safeMessage(e)) + ");");
                }
            });
        }
    }

    private String readUri(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new IllegalStateException("Cannot read selected file");
            byte[] b = new byte[16384]; int n;
            while ((n = in.read(b)) >= 0) {
                out.write(b, 0, n);
                if (out.size() > 150 * 1024 * 1024) throw new IllegalStateException("JSON file is larger than 150 MB");
            }
            return out.toString("UTF-8");
        }
    }

    void js(String script) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(script, null);
        });
    }

    void clearWebRuntimeCache() {
        if (webView == null) return;
        webView.clearCache(true);
        webView.clearHistory();
    }

    static String safeMessage(Throwable t) {
        String m = t.getMessage();
        return (m == null || m.trim().isEmpty()) ? t.getClass().getSimpleName() : m;
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("window.handleAndroidBack ? window.handleAndroidBack() : 'false'", value -> {
            if (!"true".equals(value) && !"\"true\"".equals(value)) {
                if (webView.canGoBack()) webView.goBack(); else MainActivity.super.onBackPressed();
            }
        });
    }

    @Override protected void onDestroy() {
        if (bridge != null) bridge.cancelSync();
        if (executor != null) executor.shutdownNow();
        if (webView != null) {
            webView.removeJavascriptInterface("Native");
            webView.destroy();
        }
        if (db != null) db.close();
        super.onDestroy();
    }
}
